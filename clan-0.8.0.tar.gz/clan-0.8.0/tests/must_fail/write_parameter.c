#pragma scop
for (i = 0; i < n ; i++)
  n = i;
#pragma endscop

