int i, *A;

for (i = N; i < M; ++i)
{
  {
    {
      {
        A[i] = i;
      }
    }/**/
  /**/}
}
