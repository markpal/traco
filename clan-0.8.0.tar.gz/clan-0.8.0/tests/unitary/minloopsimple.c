#pragma scop
for (i = 0; i < min(m,n); ++i)
  a = 0;
#pragma endscop
