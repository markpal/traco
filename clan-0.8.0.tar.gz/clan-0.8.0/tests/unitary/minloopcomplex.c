#pragma scop
for (i = 0; i < min(min(m,q),min(n,min(p,o))); ++i)
  a = 0;
#pragma endscop
