#pragma scop
for (i = 0; i >= 2; i++)
  a = 0;
#pragma endscop
