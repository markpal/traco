#pragma scop
a = (b = c ? d : e) ? f : g;
#pragma endscop
