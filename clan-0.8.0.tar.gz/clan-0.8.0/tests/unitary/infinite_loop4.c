#pragma scop
while (1)
  for (i = 0; i <= N; i++)
    for (;;)
      S1();
#pragma endscop
