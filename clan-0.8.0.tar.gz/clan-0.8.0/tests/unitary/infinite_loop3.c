#pragma scop
for (i = 0; i <= N; i++)
  while (1)
    for (j = 0; j <= N; j++)
      S1();
#pragma endscop
