#pragma scop
a;
#pragma endscop
