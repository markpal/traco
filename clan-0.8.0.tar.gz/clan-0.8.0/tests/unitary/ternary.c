#pragma scop
b = c < d ? a + 1 : 2 * b; 
#pragma endscop
