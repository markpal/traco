#pragma scop
for (i = 0; i < n; ++i)
   printf (a[i+1],b[n]);
#pragma endscop
