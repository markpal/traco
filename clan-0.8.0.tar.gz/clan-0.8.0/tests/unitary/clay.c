#pragma scop
/* Clay
   reorder([0], [1,0]);
 */
a = 0;
b = 0;
#pragma endscop
