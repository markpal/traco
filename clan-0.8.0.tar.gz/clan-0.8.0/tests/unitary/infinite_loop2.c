#pragma scop
for (i = 0; i <= N; i++)
  while (1)
    S1();
#pragma endscop
