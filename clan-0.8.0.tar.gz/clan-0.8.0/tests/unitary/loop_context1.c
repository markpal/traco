#pragma scop
for (i = N; i <= M; i++)
  a = 0;
#pragma endscop
