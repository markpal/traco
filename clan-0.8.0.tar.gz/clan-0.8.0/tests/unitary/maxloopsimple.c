#pragma scop
for (i = max(m,n); i < n; ++i)
  a = 0;
#pragma endscop
