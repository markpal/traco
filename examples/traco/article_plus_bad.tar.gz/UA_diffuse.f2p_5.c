#include<omp.h>
#include<stdlib.h>
#include<stdio.h>

int N = 50;
int N1, N2, N3, N4, DIM;
int DIM1;
int DIM2;
int DIM3;





void seq(float u[DIM1][DIM2][DIM3], float wdtdr[DIM1][DIM2], float r[DIM1][DIM2][DIM3]) {
int k, iz, i, j;

    for(k = 1; k <= N1; k++){
      for(iz = 1; iz <= N2; iz++){
        for(j = 1; j <= N3; j++){
          for(i = 1; i <= N4; i++){
            r[i][j][iz] = r[i][j][iz]+u[i][j][k]*wdtdr[k][iz];
          }
        }
      }
    }
}


void comp(float u[DIM1][DIM2][DIM3], float wdtdr[DIM1][DIM2], float r[DIM1][DIM2][DIM3]) {
int t2,t3,t4,t1;

if (N3 >= 1 && N1 >= 2 && N4 >= 1) {
  #pragma omp parallel for  private(t4,t2,t3,t1)
  for(t2 = 1; t2 <= N2; t2++) {
    for(t3 = 1; t3 <= N3; t3++) {
      for(t4 = 1; t4 <= N4; t4++) {
        r[t4][t3][t2]=r[t4][t3][t2]+u[t4][t3][1]*wdtdr[1][t2];
        if (t2 <= N2 && t4 >= 1 && t4 <= N4 && t3 >= 1 && N3 >= t3 && t2 >= 1) {
          for(t1 = 2; t1 <= N1; t1++) {
            r[t4][t3][t2]=r[t4][t3][t2]+u[t4][t3][t1]*wdtdr[t1][t2];
          }
        }

      }
    }
  }
}

}




int main(int argc, char *argv[]) {

  // number of processors
  int num_proc=1;
  num_proc = atoi(argv[1]);

  if(argc > 2)
    N = atoi(argv[2]);

  N1 = N2 = N3 = N4 = N;
  DIM = DIM1 = DIM2 = DIM3 = N+2;

  float (*u)[DIM2][DIM3], (*wdtdr)[DIM2], (*r)[DIM2][DIM3];
  wdtdr = (float (*)[DIM2])malloc(DIM1 * DIM2 * sizeof(float));
  r = (float (*)[DIM2][DIM3])malloc(DIM1 * DIM2 * DIM3 * sizeof(float));
  u = (float (*)[DIM2][DIM3])malloc(DIM1 * DIM2 * DIM3 * sizeof(float));

  // variables to meassure time
  struct timeval s1, f1;
  double  duration, duration1;

  printf("Ilosc procesorow: %i \n\n", num_proc);
  omp_set_num_threads(num_proc);

  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  gettimeofday(&s1, NULL);

  if(num_proc == 1)
    seq(u, wdtdr, r);
  else
    comp(u, wdtdr, r);

  gettimeofday(&f1, NULL);

  // -----------------------------------
  // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  duration = (double)f1.tv_sec + ((double)f1.tv_usec/1000000) - ((double)s1.tv_sec + ((double)s1.tv_usec/1000000));
  printf("Czas sekwencyjny: %2.3f seconds\n", duration);




}


