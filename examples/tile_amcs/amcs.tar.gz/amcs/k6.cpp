#include <omp.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#define ceild(n,d)  ceil(((double)(n))/((double)(d)))
#define floord(n,d) floor(((double)(n))/((double)(d)))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))

using namespace std;


int N = 1024;

// k6 - LiverMoore
int main(int argc, char *argv[]) {

    int kind = atoi(argv[1]);
	int N = atoi(argv[2]);

	int k,l,i,j,t,loop=N,n=N;

	// Declare arrays on the stack
	long double **b = new long double*[N];
	for (i=0; i<N; i++)
	  b[i] = new long double[N];
        long double  *w = new long double[N];
        long double  *w1 = new long double[N];

	// Set the input data
	for (i=0; i<N; i++) {
                w1[i] = w[i] = 0.002*sin(i);
//                w1[i] = 0.002;
		for (j=0; j<N; j++) {
			b[i][j] = 0.001;
		}
	}
omp_set_num_threads(1);
long double sum;
double start = omp_get_wtime();
// -- sekw.
// -----------------------------------
if(kind == 1){

    for ( l=1 ; l<=loop ; l++ ) {
        for ( i=1 ; i<n ; i++ ) {
//            sum =0;
//            #pragma omp parallel for reduction(+: sum)
            for ( k=0 ; k<i ; k++ ) {
                w[i] += b[k][i] * w[(i-k)-1];
//            w[i] = sum;
            }
        }
    }
}
// pluto
// -----------------------------------
else if(kind == 3){



}else{

    //traco

int c0,c1,c2,c3,c4,c5;


int a = 0;
    for ( l=1 ; l<=loop ; l++ ) {
        for ( i=1 ; i<n ; i++ ) {
            for ( k=0 ; k<i ; k++ ) {
//                w1[i] += b[k][i] * w1[(i-k)-1];
//                a++;
            }
        }
    }
cout << a << endl;
a=0;
start = omp_get_wtime();

for ( l=1 ; l<=loop ; l++ ) {
/*for (c0 = 0; c0 <= floord(n - 2, 32); c0 += 1)
  for (c1 = 0; c1 <= c0; c1 += 1)
      if (c0 >= c1 + 1) {
            for (c3 = 32 * c1; c3 <= 32 * c1 + 31; c3 += 1)
                    w[32*c0+1]=w[32*c0+1]+b[c3][32*c0+1]*w[32*c0+1-c3-1];
                        } else
                              for (c2 = 32 * c0 + 1; c2 <= min(32 * c0 + 32, n - 1); c2 += 1) {
                                      if (c2 >= 32 * c0 + 2)
                                                for (c3 = 0; c3 < 32 * c0; c3 += 1)
                                                            w[c2]=w[c2]+b[c3][c2]*w[c2-c3-1];
                                                                    for (c3 = 32 * c0; c3 < c2; c3 += 1)
                                                                              w[c2]=w[c2]+b[c3][c2]*w[c2-c3-1];
                                                                                    }
*/

for (c0 = 0; c0 <= floord(n - 2, 32); c0 += 1)
  for (c1 = 0; c1 <= c0; c1 += 1)
      for (c2 = 32 * c0 + 1; c2 <= min(n - 1, 32 * c0 + 32); c2 += 1) {
            if (c1 == 0 && c0 == 0 && c2 >= 2) {
//a++;
                    w[c2]=w[c2]+b[0][c2]*w[c2-0-1];
                          } else if (c1 == c0 && c0 >= 1 && c2 >= 32 * c0 + 2)
//a++;
                                  w[c2]=w[c2]+b[0][c2]*w[c2-0-1];
                                        for (c3 = max(32 * c1, -c0 + floord(-c0 + c2 - 2, 31) + 1); c3 <= min(32 * c1 + 31, c2 - 1); c3 += 1)
//a++;
                                                w[c2]=w[c2]+b[c3][c2]*w[c2-c3-1];
                                                    }


}



}



    double end = omp_get_wtime();
	printf("%.3f\n", end - start);

	#pragma endscop


	for (i=0; i<N; i++) {
	if (w[i] != w1[i])
	printf("error");
	exit(0);
	}


	// Clean-up and exit the function
	fflush(stdout);
	return 0;
}
