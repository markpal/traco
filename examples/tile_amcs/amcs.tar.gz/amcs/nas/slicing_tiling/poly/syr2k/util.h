#include <omp.h>

int num_proc=1;

#define NMAX 2048
