#include <omp.h>

int num_proc=1;

#define N 3000
#define M 3000
