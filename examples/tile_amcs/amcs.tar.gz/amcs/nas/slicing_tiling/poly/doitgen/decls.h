#define N 250

double A[N][N][N];
double sum[N][N][N];
double C4[N][N];
