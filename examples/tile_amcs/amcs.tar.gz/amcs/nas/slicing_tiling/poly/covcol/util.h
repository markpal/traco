#include <omp.h>

int num_proc=1;

#define N 2000
#define M 2000

