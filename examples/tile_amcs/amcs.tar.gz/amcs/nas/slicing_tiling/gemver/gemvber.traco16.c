#include <omp.h>
#include <math.h>
#define ceild(n,d)  ceil(((double)(n))/((double)(d)))
#define floord(n,d) floor(((double)(n))/((double)(d)))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))


#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>

#define N 11000

#define alpha 1
#define beta 1

#pragma declarations
double A[N][N];
double B[N][N];

double x[N];
double u1[N];
double u2[N];
double v2[N];
double v1[N];
double w[N];
double y[N];
double z[N];
#pragma enddeclarations

#ifdef TIME
#define IF_TIME(foo) foo;
#else
#define IF_TIME(foo)
#endif

void init_array()
{
    int i, j;

    for (i=0; i<N; i++) {
        u1[i] = i;
        u2[i] = (i+1)/N/2.0;
        v1[i] = (i+1)/N/4.0;
        v2[i] = (i+1)/N/6.0;
        y[i] = (i+1)/N/8.0;
        z[i] = (i+1)/N/9.0;
        x[i] = 0.0;
        w[i] = 0.0;
        for (j=0; j<N; j++) {
            A[i][j] = ((double) i*j)/N;
        }
    }
}

void print_array()
{
    int i, j;

    for (i=0; i<N; i++) {
        fprintf(stderr, "%0.2lf ", w[i]);
        if (i%80 == 20) fprintf(stderr, "\n");
    }
    fprintf(stderr, "\n");
}


double rtclock()
{
    struct timezone Tzp;
    struct timeval Tp;
    int stat;
    stat = gettimeofday (&Tp, &Tzp);
    if (stat != 0) printf("Error return from gettimeofday: %d",stat);
    return(Tp.tv_sec + Tp.tv_usec*1.0e-6);
}

int main(int argc, char** argv)
{
    double t_start, t_end;
    int i, j;

    init_array();

    t_start = rtclock();
//int ub = floord(N - 1, 400);
int c0,c1,c2,c3,c4,c6,c0_0;

  int num_proc = atoi(argv[1]);

  omp_set_num_threads(num_proc);

int ub = floord(N - 1, 400);
int ub2 = floord(N - 1, 16);
register int lbv; 
register int ubv; 
#pragma omp parallel for
for (c0 = 0; c0 <= ub2; c0 += 1)
  for (c1 = 0; c1 <= (N - 1) / 16; c1 += 1)
     for (c3 = 16 * c1; c3 <= min(N - 1, 16 * c1 + 15); c3 += 1) {
lbv=  400*c0;
ubv =  min(N - 1, 400 * c0 + 399);
#pragma ivdep 
#pragma vector always
      for (c2 = lbv; c2 <=ubv; c2 += 1){
                    B[c3][c2]=A[c3][c2]+u1[c3]*v1[c2]+u2[c3]*v2[c2];
                    }
#pragma ivdep 
#pragma vector always
lbv =  400*c0;
ubv =  min(N - 1, 400 * c0 + 399);
      for (c2 = lbv; c2 <= ubv; c2 += 1){            
                            x[c2]=x[c2]+beta*B[c3][c2]*y[c3];
                                  }
}

#pragma omp parallel for
    for (i=0; i<N; i++)
        x[i] = x[i] + z[i];

#pragma omp parallel for
for (c0 = 0; c0 <= ub; c0 += 1)
  for (c1 = 0; c1 <= (N - 1) / 16; c1 += 1)
      for (c2 = 400 * c0; c2 <= min(N - 1, 400 * c0 + 399); c2 += 1)
            for (c3 = 16 * c1; c3 <= min(N - 1, 16 * c1 + 15); c3 += 1)
                    w[c2]=w[c2]+alpha*B[c2][c3]*x[c3];

 t_end= rtclock();
  printf("%0.6f\n", t_end - t_start);

    if (fopen(".test", "r")) {
#ifdef MPI
        if (my_rank == 0) {
            print_array();
        }
#else
        print_array();
#endif
    }

    return 0;
}
