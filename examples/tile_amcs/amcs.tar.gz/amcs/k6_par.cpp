#include <omp.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#define ceild(n,d)  ceil(((double)(n))/((double)(d)))
#define floord(n,d) floor(((double)(n))/((double)(d)))
#define max(x,y)    ((x) > (y)? (x) : (y))
#define min(x,y)    ((x) < (y)? (x) : (y))

using namespace std;


int N = 1024;

// k6 - LiverMoore
int main(int argc, char *argv[]) {

    int kind = atoi(argv[1]);
	int N = atoi(argv[2]);

	int k,l,i,j,t,loop=N,n=N;

	// Declare arrays on the stack
	long double **b = new long double*[N];
	for (i=0; i<N; i++)
	  b[i] = new long double[N];
        long double  *w = new long double[N];
        long double  *w1 = new long double[N];

	// Set the input data
	for (i=0; i<N; i++) {
                w1[i] = w[i] = 0.0001*i;
//                w1[i] = 0.002;
		for (j=0; j<N; j++) {
			b[i][j] = 0.001;
		}
	}

double start = omp_get_wtime();
// -- sekw.
// -----------------------------------
if(kind == 0){

    for ( l=1 ; l<=loop ; l++ ) {
        for ( i=1 ; i<n ; i++ ) {
            for ( k=0 ; k<i ; k++ ) {
                w[i] += b[k][i] * w[(i-k)-1];
            }
        }
    }
}
// pluto
// -----------------------------------
else if(kind == 3){



}else{

    //traco

int c0,c1,c2,c3,c4,c5;


int a = 0;
    for ( l=1 ; l<=loop ; l++ ) {
        for ( i=1 ; i<n ; i++ ) {
            for ( k=0 ; k<i ; k++ ) {
//                w1[i] += b[k][i] * w1[(i-k)-1];
//                a++;
            }
        }
    }
//cout << a << endl;
a=0;

omp_set_num_threads(kind);
start = omp_get_wtime();

int btile=32;
long double w_[48][32];
long double sum;
int lb_c0,thread_id,block,lb,ub,num_threads;

num_threads = kind;

for ( l=1 ; l<=loop ; l++ ) {     // no tiled
 for (c0 = 0; c0 <= floord(n - 2, 32); c0 += 1){
 
  lb_c0 = 32*c0+1;    //offset i
  
  #pragma omp parallel private(i,w_,c1,c2,c3,lb,ub,thread_id) shared(c0,b,lb_c0,num_threads,btile,sum)
  {
    thread_id = omp_get_thread_num();
    block = c0 / num_threads ;
    lb = thread_id * block;     //granice po c1
    ub = min((thread_id+1) * block, c0-1);

  for(i=0; i<btile; i++){
     w_[thread_id][i] = 0;
     }
                         
     for (c1 = lb; c1 <= ub; c1 += 1)            //  for (c1 = 0; c1 <= c0-1; c1 += 1)
       for (c2 =32*c0+1; c2 <= min(n - 1, 32 * c0 + 32); c2 += 1) {
         if (c1 == 0 && c0 == 0 && c2 >= 2) 
           w_[thread_id][c2-lb_c0] += b[0][c2]*w[c2-0-1];
         for (c3 = max(32 * c1, -c0 + floord(-c0 + c2 - 2, 31) + 1); c3 <= min(32*c1 + 31, c2-1); c3++)
           w_[thread_id][c2-lb_c0] += b[c3][c2]*w[c2-c3-1];
        }
                                                                   
     
      #pragma omp critical
      {   
        for(i=0; i<btile; i++)        
           w[lb_c0+i] += w_[thread_id][i];
      }


     
                                                                      
    }
                                                                      
    // the last block
    for (c2 = 32 * c0 + 1; c2 <= min(n - 1, 32 * c0 + 32); c2 += 1) {
    // c1 = c0   block
     if (c0 >= 1 && c2 >= 32 * c0 + 2)    
      w[c2]=w[c2]+b[0][c2]*w[c2-0-1];
       for (c3 = max(32 * c0, -c0 + floord(-c0 + c2 - 2, 31) + 1); c3 <= min(32*c0 + 31, c2-1); c3++)
        w[c2]=w[c2]+b[c3][c2]*w[c2-c3-1];
        }                                                                                                  
  }  
}
}
        double end = omp_get_wtime();
	printf("%.3f\t", end - start);

	#pragma endscop


	for (i=0; i<N; i++) {
	if (w[i] != w1[i])
	printf("error\n");
	exit(0);
	}


	// Clean-up and exit the function
	fflush(stdout);
	return 0;
}
